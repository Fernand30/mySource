/********************************************************************************
** Form generated from reading UI file 'splash.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPLASH_H
#define UI_SPLASH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_splash
{
public:
    QLabel *label;

    void setupUi(QDialog *splash)
    {
        if (splash->objectName().isEmpty())
            splash->setObjectName(QStringLiteral("splash"));
        splash->resize(750, 430);
        splash->setStyleSheet(QLatin1String("QDialog#splash{\n"
"	background-image: url(:/images/splash.png);\n"
"}"));
        label = new QLabel(splash);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(120, 330, 521, 61));
        QFont font;
        font.setPointSize(22);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setStyleSheet(QStringLiteral("color: #cdcde1;"));

        retranslateUi(splash);

        QMetaObject::connectSlotsByName(splash);
    } // setupUi

    void retranslateUi(QDialog *splash)
    {
        splash->setWindowTitle(QApplication::translate("splash", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("splash", "Forensics Image Acquisition Helper ", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class splash: public Ui_splash {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPLASH_H
