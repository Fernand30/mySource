#ifndef SPLASH_H
#define SPLASH_H

#include <QDialog>

namespace Ui {
class splash;
}

class splash : public QDialog
{
    Q_OBJECT

public:
    explicit splash(QWidget *parent = 0);
    ~splash();

private:
    void    completeUi();

    Ui::splash *ui;
private slots:
    void    updateCaption();
};

#endif // SPLASH_H
