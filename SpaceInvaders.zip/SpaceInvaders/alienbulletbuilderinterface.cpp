#include "alienbulletbuilderinterface.h"

AlienBulletBuilderInterface::AlienBulletBuilderInterface()
{

}
