#include "scoredlg.h"
#include "ui_scoredlg.h"
#include "mainmenu.h"

scoreDlg::scoreDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::scoreDlg)
{
    ui->setupUi(this);
}

scoreDlg::~scoreDlg()
{
    delete ui;
}

void scoreDlg::on_return_btn_clicked()
{
    mainmenu *menudlg  = new mainmenu();
    menudlg->show();
    close();
}
